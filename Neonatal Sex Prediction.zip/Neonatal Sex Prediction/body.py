#  Predict Gender from Name
#  Using a dataset of popular Western names from the US, UK, Canada, and Australia.


#  import frequently used libraries
import pandas as pd
import tensorflow as tf
from matplotlib import pyplot as plt
from collections import namedtuple
#  Load Dataset
dataframe = pd.read_csv("name_gender_dataset.csv")

#  Clean Dataset
#  Discard names that are not frequently used.
dataframe_filtered = dataframe.loc[dataframe["Count"] >= 100]

#  Generate Vocabulary
Vocabulary = namedtuple('Vocabulary', ['VOCAB_SIZE', 'character2index'])


def get_vocabulary(data_column):
    all_characters = set()
    for entry in data_column:
        all_characters |= set(entry.lower())

    all_characters = sorted(all_characters)

    print(f"The vocabulary includes {len(all_characters)} characters: {all_characters}")

    char2idx = {}

    for idx, char in enumerate(all_characters):
        char2idx[char] = idx

    vocab_size = len(all_characters)

    # turn into function so it's callable
    char2idx_fcn = lambda c: char2idx[c]

    return Vocabulary(vocab_size, char2idx_fcn)


vocab = get_vocabulary(dataframe_filtered['Name'])


def word2indices(word, vocab):
    return [vocab.character2index(c.lower()) for c in word]


def word2onehot(word, vocab):
    indices = word2indices(word.strip(), vocab)
    onehot = tf.one_hot(indices, depth=vocab.VOCAB_SIZE)
    return onehot


# Test if the function works as intended
word2onehot('abc', vocab)


def gender2float(gender):
    return 1.0 if gender == 'M' else 0.0


def float2gender(num, threshold=0.1):
    if num < 0.5 - threshold:
        return 'F'
    if num > 0.5 + threshold:
        return 'M'
    return 'UNKNOWN'


#  Convert Training Data
TrainingData = namedtuple('TrainingData', ['inputs', 'targets'])


def convert_to_training_data(raw_inputs, raw_outputs, vocab):
    # convert the strings to arrays of indices
    input_indices = raw_inputs.map(lambda w: word2indices(w.strip(), vocab))

    outputs = raw_outputs.map(lambda gender: gender2float(gender))

    x_train = tf.ragged.constant(input_indices)
    x_train = tf.one_hot(x_train, depth=vocab.VOCAB_SIZE)

    y_train = tf.constant(outputs)

    return TrainingData(x_train, y_train)


training_data = convert_to_training_data(dataframe_filtered['Name'], dataframe_filtered['Gender'], vocab)


#  Define and Train Model
def get_model(memory_size, vocab_size):
    model = tf.keras.Sequential([
        tf.keras.Input((None, vocab_size), ragged=True),
        tf.keras.layers.SimpleRNN(memory_size),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    model.summary()

    return model


# size of the "memory" of the RNN (size of the state vector passed to next time step)
MEMORY_SIZE = 50

model = get_model(MEMORY_SIZE, vocab.VOCAB_SIZE)

optimizer = tf.keras.optimizers.Adam(learning_rate=0.0005)

model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=['acc'])

BATCH_SIZE = 64
NUM_EPOCHS = 30
# VALIDATION_SPLIT = 0.2

history = model.fit(x=training_data.inputs, y=training_data.targets, batch_size=BATCH_SIZE, epochs=NUM_EPOCHS)


def plot_history(history):
    for key, values in history.items():
        plt.plot(values)
        plt.title(key)
        plt.xlabel('epoch')
        plt.show()


plot_history(history.history)


#  Predict and Analyze
def predict_gender(model, name):
    test_input = word2onehot(name.lower(), vocab)
    # add batch dimension of 1
    test_input = tf.reshape(test_input, (1, test_input.shape[0], test_input.shape[1]))

    return model.predict(test_input).flatten()[0]

#  Enter the name to predict
name = 'jessie'

prob = predict_gender(model, name)

print(f"Model predicts that {name} is {float2gender(prob)} (output = {prob})")
